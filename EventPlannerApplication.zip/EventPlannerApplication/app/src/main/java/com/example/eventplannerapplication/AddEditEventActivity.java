package com.example.eventplannerapplication;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.eventplannerapplication.RoomDatabase.Event;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AddEditEventActivity extends AppCompatActivity {
    private EditText editTextTitle, editTextDescription;
    private TextView textViewDate, textViewTime;
    private Button buttonSave;
    private EventViewModel eventViewModel;
    private Event event;
    private long selectedDate, selectedTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_event);

        editTextTitle = findViewById(R.id.editTextTitle);
        editTextDescription = findViewById(R.id.editTextDescription);
        textViewDate = findViewById(R.id.textViewDate);
        textViewTime = findViewById(R.id.textViewTime);
        buttonSave = findViewById(R.id.buttonSave);
        eventViewModel = new ViewModelProvider(this).get(EventViewModel.class);

        Intent intent = getIntent();
        if (intent.hasExtra("event")) {
            /** Editing existing event**/
            event = (Event) intent.getSerializableExtra("event");
            editTextTitle.setText(event.getTitle());
            editTextDescription.setText(event.getDescription());

            selectedDate = event.getDate();
            selectedTime = event.getTime();

            textViewDate.setText(formatDate(selectedDate));
            textViewTime.setText(formatTime(selectedTime));
        } else {
            /** Adding a new event**/
            selectedDate = intent.getLongExtra("selectedDate", System.currentTimeMillis());
            selectedTime = System.currentTimeMillis(); // Default to current time
            textViewDate.setText(formatDate(selectedDate));
            textViewTime.setText(formatTime(selectedTime));
        }

        textViewDate.setOnClickListener(v -> pickDate());
        textViewTime.setOnClickListener(v -> pickTime());
        buttonSave.setOnClickListener(v -> saveEvent());
    }

    private void pickDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(selectedDate);

        DatePickerDialog datePicker = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            Calendar selectedCal = Calendar.getInstance();
            selectedCal.set(year, month, dayOfMonth);
            selectedDate = selectedCal.getTimeInMillis();
            textViewDate.setText(formatDate(selectedDate));
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));

        datePicker.show();
    }

    private void pickTime() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(selectedTime);

        TimePickerDialog timePicker = new TimePickerDialog(this, (view, hourOfDay, minute) -> {
            Calendar selectedCal = Calendar.getInstance();
            selectedCal.set(Calendar.HOUR_OF_DAY, hourOfDay);
            selectedCal.set(Calendar.MINUTE, minute);
            selectedCal.set(Calendar.SECOND, 0);
            selectedCal.set(Calendar.MILLISECOND, 0);
            selectedTime = selectedCal.getTimeInMillis();
            textViewTime.setText(formatTime(selectedTime));
        }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true);

        timePicker.show();
    }

    private void saveEvent() {
        String title = editTextTitle.getText().toString().trim();
        String description = editTextDescription.getText().toString().trim();
        String dateString = textViewDate.getText().toString();  // Example: "2025-03-06"
        String timeString = textViewTime.getText().toString();  // Example: "14:30"

        if (title.isEmpty() || description.isEmpty() || dateString.isEmpty() || timeString.isEmpty()) {
            Toast.makeText(this, "Please enter all details", Toast.LENGTH_SHORT).show();
            return;
        }

        // ✅ Convert Date and Time to milliseconds
        long dateInMillis = convertDateToMillis(dateString);
        long timeInMillis = convertTimeToMillis(timeString);
        long eventTimeInMillis = dateInMillis + (timeInMillis % (24 * 60 * 60 * 1000)); // Combine date and time

        String formattedDate = formatDate(dateInMillis);
        String formattedTime = formatTime(timeInMillis);

        Log.d("EventPlanner", "Event Saved: " + formattedDate + " " + formattedTime);

        if (event == null) {
            event = new Event(title, description, dateInMillis, timeInMillis, true);
            eventViewModel.insert(event);
        } else {
            event.setTitle(title);
            event.setDescription(description);
            event.setDate(dateInMillis);
            event.setTime(timeInMillis);
            event.setHasReminder(true);
            eventViewModel.update(event);
        }

        scheduleNotification(eventTimeInMillis, title);

        finish();
    }
    private void scheduleNotification(long eventTimeInMillis, String eventTitle) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, ReminderBroadcastReceiver.class);
        intent.putExtra("eventTitle", eventTitle);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this, (int) eventTimeInMillis, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        if (alarmManager != null) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, eventTimeInMillis, pendingIntent);
            Log.d("EventPlanner", "Notification scheduled for: " + new Date(eventTimeInMillis));
        }
    }


    private long convertDateToMillis(String dateString) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        try {
            return sdf.parse(dateString).getTime();
        } catch (ParseException e) {
            e.printStackTrace();
            return System.currentTimeMillis();
        }
    }

    private long convertTimeToMillis(String timeString) {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
        try {
            return sdf.parse(timeString).getTime();
        } catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }
    }


    private String formatDate(long timestamp) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date(timestamp));
    }

    private String formatTime(long timestamp) {
        return new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(timestamp));
    }
}
