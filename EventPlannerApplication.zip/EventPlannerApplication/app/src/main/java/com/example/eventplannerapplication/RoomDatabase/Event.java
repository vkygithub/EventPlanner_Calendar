package com.example.eventplannerapplication.RoomDatabase;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import java.io.Serializable;

@Entity(tableName = "events")
public class Event implements Serializable {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String title;
    private String description;
    private long date;
    private long time;
    private boolean hasReminder;


    public Event() {
    }

    public Event(String title, String description, long dateInMillis, long timeInMillis, boolean b) {
        this.title = title;
        this.description = description;
        this.date = dateInMillis;
        this.time = timeInMillis;
        this.hasReminder = b;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public long getDate() { return date; }
    public void setDate(long date) { this.date = date; }

    public long getTime() { return time; }
    public void setTime(long time) { this.time = time; }

    public boolean isHasReminder() { return hasReminder; }
    public void setHasReminder(boolean hasReminder) { this.hasReminder = hasReminder; }
}

