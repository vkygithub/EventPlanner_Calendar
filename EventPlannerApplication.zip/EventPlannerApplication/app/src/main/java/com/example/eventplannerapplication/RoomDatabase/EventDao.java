package com.example.eventplannerapplication.RoomDatabase;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;
@Dao
public interface EventDao {
    @Insert
    void insert(Event event);

    @Update
    void update(Event event);

    @Delete
    void delete(Event event);

    /**All the events to ordered**/
    @Query("SELECT * FROM events ORDER BY date ASC, time ASC")
    LiveData<List<Event>> getAllEvents();

    /**Search Events by the title**/
    @Query("SELECT * FROM events WHERE title LIKE '%' || :query || '%' ORDER BY date ASC, time ASC")
    LiveData<List<Event>> searchEvents(String query);

    @Query("SELECT * FROM events WHERE date BETWEEN :startDate AND :endDate ORDER BY date ASC, time ASC")
    LiveData<List<Event>> filterEvents(long startDate, long endDate);

}




