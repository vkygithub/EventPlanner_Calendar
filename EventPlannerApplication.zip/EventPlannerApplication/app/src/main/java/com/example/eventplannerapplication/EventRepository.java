package com.example.eventplannerapplication;

import android.app.Application;

import androidx.lifecycle.LiveData;
import com.example.eventplannerapplication.RoomDatabase.Event;
import com.example.eventplannerapplication.RoomDatabase.EventDao;
import com.example.eventplannerapplication.RoomDatabase.EventDatabase;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class EventRepository {
    private EventDao eventDao;
    private LiveData<List<Event>> allEvents;
    private ExecutorService executorService = Executors.newSingleThreadExecutor();

    public EventRepository(Application application) {
        EventDatabase database = EventDatabase.getInstance(application);
        eventDao = database.eventDao();
        allEvents = eventDao.getAllEvents();
    }

    public void insert(Event event) {
        executorService.execute(() -> eventDao.insert(event));
    }

    public void update(Event event) {
        executorService.execute(() -> eventDao.update(event));
    }

    public void delete(Event event) {
        executorService.execute(() -> eventDao.delete(event));
    }

    public LiveData<List<Event>> getAllEvents() {
        return allEvents;
    }

    public LiveData<List<Event>> searchEvents(String query) {
        return eventDao.searchEvents("%" + query + "%");
    }

    public LiveData<List<Event>> filterEvents(long startDate, long endDate) {
        return eventDao.filterEvents(startDate, endDate);
    }
}

