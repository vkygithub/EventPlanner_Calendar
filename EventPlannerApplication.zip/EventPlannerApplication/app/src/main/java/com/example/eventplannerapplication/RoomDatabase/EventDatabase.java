package com.example.eventplannerapplication.RoomDatabase;

import android.content.Context;
import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {Event.class}, version = 2, exportSchema = false)
public abstract class EventDatabase extends RoomDatabase {
    public abstract EventDao eventDao();

    private static volatile EventDatabase INSTANCE;

    public static EventDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (EventDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    EventDatabase.class, "event_database")
                            .addMigrations(MIGRATION_1_2)  // 👈 Add migration
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    // Migration from version 1 to 2
    static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            // Check if the column already exists before adding it
            Cursor cursor = database.query("PRAGMA table_info(events)");
            boolean columnExists = false;
            while (cursor.moveToNext()) {
                String columnName = cursor.getString(1);
                if (columnName.equals("hasReminder")) {
                    columnExists = true;
                    break;
                }
            }
            cursor.close();

            if (!columnExists) {
                /** Edit the old Events**/
                database.execSQL("ALTER TABLE events RENAME TO events_old");

                /** Create a new Events**/
                database.execSQL("CREATE TABLE events (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "title TEXT, " +
                        "description TEXT, " +
                        "date INTEGER NOT NULL, " +
                        "time INTEGER NOT NULL, " +
                        "hasReminder INTEGER NOT NULL)");

                /** Copy the old Events**/
                database.execSQL("INSERT INTO events (id, title, description, date, time, hasReminder) " +
                        "SELECT id, title, description, dateTime, 0, hasReminder FROM events_old");

                /** Delete the old Events**/
                database.execSQL("DROP TABLE events_old");
            }
        }
    };

}
