package com.example.eventplannerapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.CalendarView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.eventplannerapplication.RoomDatabase.Event;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.List;
import android.os.Bundle;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private EventViewModel eventViewModel;
    private EventAdapter adapter;
    private long selectedDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        CalendarView calendarView = findViewById(R.id.calendarView);
        RecyclerView recyclerView = findViewById(R.id.recyclerViewEvents);
        FloatingActionButton fab = findViewById(R.id.fabAddEvent);
        SearchView searchView = findViewById(R.id.searchView);

        selectedDate = System.currentTimeMillis();

        adapter = new EventAdapter();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        eventViewModel = new ViewModelProvider(this).get(EventViewModel.class);
        eventViewModel.getAllEvents().observe(this, this::updateEventList);
        searchView.setQueryHint("Search Events Title...");
        searchView.setIconifiedByDefault(true);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                searchEvents(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                searchEvents(newText);
                return true;
            }
        });
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            selectedDate = new java.util.GregorianCalendar(year, month, dayOfMonth).getTimeInMillis();
            filterEventsByDate();
        });

        fab.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddEditEventActivity.class);
            intent.putExtra("selectedDate", selectedDate);
            startActivity(intent);
        });

        adapter.setOnItemClickListener(new EventAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Event event) {
                Intent intent = new Intent(MainActivity.this, AddEditEventActivity.class);
                intent.putExtra("event", event); // Pass the event object
                startActivity(intent);
            }

            @Override
            public void onEditClick(Event event) {
                Intent intent = new Intent(MainActivity.this, AddEditEventActivity.class);
                intent.putExtra("event", event); // Pass event to be edited
                startActivity(intent);
            }

            @Override
            public void onDeleteClick(Event event) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Delete Event")
                        .setMessage("Are you sure you want to delete this event?")
                        .setPositiveButton("Yes", (dialog, which) -> {
                            eventViewModel.delete(event);
                            Toast.makeText(MainActivity.this, "Event Deleted", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("No", null)
                        .show();
            }
        });

    }

    private void updateEventList(List<Event> events) {
        adapter.setEvents(events);
        filterEventsByDate();
    }

    private void searchEvents(String query) {
        eventViewModel.searchEvents(query).observe(this, adapter::setEvents);
    }

    private void filterEventsByDate() {
        eventViewModel.filterEvents(selectedDate, selectedDate + 86400000).observe(this, adapter::setEvents);
    }
}